﻿using WebApplication1.Food.Domain;

namespace WebApplication1.Food.Infrastructure
{
    public class FoodRepo : IFoodRepository
    {
        public List<FoodModel> GetAllSold()
        {
            //In a real project, this is where you 
            //would call your database/datastore for this info
            List<FoodModel> items = new List<FoodModel>()
        {
            new FoodModel()
            {
                ID = 14,
                Name = "Milk Duds",
                SalePrice = 4.99M,
                UnitPrice = 1.69M,
                Quantity = 43
            },
            new FoodModel()
            {
                ID = 3,
                Name = "Sour Gummy Worms",
                SalePrice = 4.89M,
                UnitPrice = 1.13M,
                Quantity = 319
            },
            new FoodModel()
            {
                ID = 18,
                Name = "Large Soda",
                SalePrice = 5.69M,
                UnitPrice = 0.47M,
                Quantity = 319
            },
            new FoodModel()
            {
                ID = 19,
                Name = "X-Large Soda",
                SalePrice = 6.19M,
                UnitPrice = 0.59M,
                Quantity = 252
            },
            new FoodModel()
            {
                ID = 1,
                Name = "Large Popcorn",
                SalePrice = 5.59M,
                UnitPrice = 1.12M,
                Quantity = 217
            }
        };

            return items;
        }
    }
}

﻿using WebApplication1.Food.Domain;

namespace WebApplication1.Food.Application
{
    public class FoodService : IFoodService
    {
        private readonly IFoodRepository _foodRepo;

        public FoodService(IFoodRepository foodRepo)
        {
            _foodRepo = foodRepo;
        }

        // There you can adapt the answer
        public List<FoodModel> GetAllSold() => _foodRepo.GetAllSold();
    }
}
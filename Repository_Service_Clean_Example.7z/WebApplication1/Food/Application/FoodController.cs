﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Food.Application
{
    [Route("api/[controller]")]
    [ApiController]
    public class FoodController : ControllerBase
    {
        // GET: api/<ValuesController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // There you can stablish some hooks or query required parameters

        // GET: api/<ValuesController>
        [HttpGet("ara")]
        public IEnumerable<string> GetAra()
        {
            return new string[] { "a", "ra" };
        }
    }
}

﻿namespace WebApplication1.Food.Domain
{
    public interface IFoodRepository
    {
        List<FoodModel> GetAllSold();
    }
}

﻿using WebApplication1.Food.Domain;

namespace WebApplication1.Food.Application
{
    public interface IFoodService
    {
        List<FoodModel> GetAllSold();
    }
}
